const { readFileSync } = require('fs');
const { gql, ApolloServer } = require('apollo-server');
const { buildFederatedSchema } = require('@apollo/federation');
const { resolve } = require('path');

let args = process.argv.slice(2);
let serviceName = args[0];
let port = args[1];

if (serviceName) {
    const schemaString = readFileSync(resolve(__dirname, `./schemas/${serviceName}.graphql`), { encoding: 'utf8' });
    const typeDefs = gql(schemaString);
    const server = new ApolloServer({
        schema: buildFederatedSchema(typeDefs),
        mocks: true,
        mockEntireSchema: false
    })

    server.listen({ port })
}