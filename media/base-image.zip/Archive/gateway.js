const { gql, ApolloServer } = require('apollo-server');
const { ApolloGateway } = require('@apollo/gateway');
const { readFileSync } = require('fs');

let serviceListJson = readFileSync('serviceList.json');
const serviceList = JSON.parse(serviceListJson);

const gateway = new ApolloGateway({
    experimental_updateServiceDefinitions: (config) => {
        let serviceDefinitions = [];

        serviceList.map(service => {
            const schema = readFileSync(`./schemas/${service.name}.graphql`, { encoding: 'utf8' });
            const typeDefs = gql(schema);
            serviceDefinitions.push({ name: service.name, url: service.url, typeDefs });
        })

        return {
            isNewSchema: true,
            serviceDefinitions
        };
    }
});
const server = new ApolloServer({
    gateway,
    subscriptions: false
})

let args = process.argv.slice(2);
let port = args[1];

server.listen({ port });
